/* 
Примерочная Лиги теней

Специальная разработка -> без применения обфускатора

Примерочная создана путём изменения для игры 5kings.ru

Полное повторение кода запрещено

Разработка окончена 13.02.2021
 */



 var	info_hp  =0;
 var	info_hp2  =0;
	
  var dam_statr1 = 0;
  var dam_statl1 = 0;
  var dam_statr2 = 0;
  var dam_statl2 = 0;
  var str_stat1	= 0;
  var str_stat2	= 0;
  
function printPersInfo()
{
 var	info_nick = 'Гость';
 var	info_rate = Body1[5][1];
 var	info_rate2 = Body2[5][1];
 var	info_id = 0;
 var	info_race =  new Array();
 		info_race['Эльф'] = 'El';
 		info_race['Человек'] = 'Hm';
 		info_race['Орк'] = 'Or';
 		info_race['Хоббит'] = 'Hb';
 		info_race['Дракон'] = 'Dr_4_mn';
 		info_race['Гном'] = 'Gn';
 			
 var    info_pic = './files/images/'+info_race[Body1[0][1]]+'.gif';
var    info_pic2 = './files/images/'+info_race[Body2[0][1]]+'.gif';
         info_race['Дракон'] = info_race['Дракон'].replace('_4_mn','');
 var	info_lvl = Body1[1][1];
 var	info_lvl2 = Body2[1][1];
 var	info_mp = Body1[4][1];
 var	info_mp2 = Body2[4][1];
 
document.getElementById('R1_damage_s').innerHTML = Math.round((dam_statl1*1+str_stat1*1*sp2[1]));
document.getElementById('L1_damage_s').innerHTML = Math.round((dam_statr1*1+str_stat1*1*sp1[1]));
document.getElementById('R1_damage_c').innerHTML = Math.round((dam_statl1*1+str_stat1*1*sp2[1])*1.5);
document.getElementById('L1_damage_c').innerHTML = Math.round((dam_statr1*1+str_stat1*1*sp1[1])*1.5);

document.getElementById('R2_damage_s').innerHTML =  Math.round((dam_statl2*1+str_stat2*1*sp2[2]));
document.getElementById('L2_damage_s').innerHTML =  Math.round((dam_statr2*1+str_stat2*1*sp1[2]));
document.getElementById('R2_damage_c').innerHTML = Math.round((dam_statl2*1+str_stat2*1*sp2[2])*1.5);
document.getElementById('L2_damage_c').innerHTML = Math.round((dam_statr2*1+str_stat2*1*sp1[2])*1.5);
 
document.getElementById('VAL_nick').style.font=((info_nick.length<17)?'bold 12px Arial, Verdana':'bold 11px Arial, Verdana');
document.getElementById('VAL_nick').innerHTML=info_nick;
document.getElementById('VAL_nick2').style.font=((info_nick.length<17)?'bold 12px Arial, Verdana':'bold 11px Arial, Verdana');
document.getElementById('VAL_nick2').innerHTML=info_nick;
 
document.getElementById('VAL_race').innerHTML=info_race[Body1[0][1]];
document.getElementById('VAL_race').title=Body1[0][1];
document.getElementById('VAL_race').className="r"+info_race[Body1[0][1]]; 

document.getElementById('VAL_race2').innerHTML=info_race[Body2[0][1]];
document.getElementById('VAL_race2').title=Body2[0][1];
document.getElementById('VAL_race2').className="r"+info_race[Body2[0][1]];

document.getElementById('VAL_mana').innerHTML=info_mp+"/"+info_mp;
document.getElementById('VAL_hp').innerHTML=info_hp+"/"+info_hp; 

document.getElementById('VAL_mana2').innerHTML=info_mp2+"/"+info_mp2;
document.getElementById('VAL_hp2').innerHTML=info_hp2+"/"+info_hp2; 

document.getElementById('ARMR_h').innerHTML=Body1[30][1];
document.getElementById('ARMR_b').innerHTML=Body1[31][1];
document.getElementById('ARMR_f').innerHTML=Body1[33][1];
document.getElementById('ARMR_r').innerHTML=Body1[32][1];
document.getElementById('ARMR_l').innerHTML=Body1[32][1]; 

document.getElementById('ARMR_h2').innerHTML=Body2[30][1];
document.getElementById('ARMR_b2').innerHTML=Body2[31][1];
document.getElementById('ARMR_f2').innerHTML=Body2[33][1];
document.getElementById('ARMR_r2').innerHTML=Body2[32][1];
document.getElementById('ARMR_l2').innerHTML=Body2[32][1]; 

document.getElementById('IMG_larm').src =d.images['ПРука1'].src.replace('em.gif','fistr2.gif');
document.getElementById('IMG_rarm').src =d.images['ЛРука1'].src.replace('em.gif','fistr2.gif');

document.getElementById('IMG_larm2').src =d.images['ПРука2'].src.replace('em.gif','fistr2.gif');
document.getElementById('IMG_rarm2').src =d.images['ЛРука2'].src.replace('em.gif','fistr2.gif');
 
document.getElementById('IMG_info').href='/info.html?user='+info_id;
document.getElementById('IMG_pers').style.backgroundImage="url("+info_pic+")";

document.getElementById('IMG_info2').href='/info.html?user='+info_id;
document.getElementById('IMG_pers2').style.backgroundImage="url("+info_pic2+")";
 
document.getElementById('VAL_lvl').innerHTML=info_lvl || 0;
document.getElementById('VAL_rnk').innerHTML=Math.floor(info_rate*10)/10;
document.getElementById('VAL_rnk').style.font=((info_rate<100)?'bold 15px Arial':'bold 17px Arial');

document.getElementById('VAL_lvl2').innerHTML=info_lvl2 || 0;
document.getElementById('VAL_rnk2').innerHTML=Math.floor(info_rate2*10)/10;
document.getElementById('VAL_rnk2').style.font=((info_rate2<100)?'bold 15px Arial':'bold 17px Arial');
}
