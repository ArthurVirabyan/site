/* 
Примерочная Лиги теней

Специальная разработка -> без применения обфускатора

Примерочная создана путём изменения для игры 5kings.ru

Полное повторение кода запрещено

Разработка окончена 13.02.2021
 */


function TestSlots(b)
{
     if(b == 1)
     for(i in Slots1)
     {
     //NumOfBody = 1;

     //if(TestItem(eval("Items[Slots"+b+"[i].id].id")) != "")
     //       eval("d.images['"+i+""+b+"'].filters.Alpha.enabled = 1");
     //else   eval("d.images['"+i+""+b+"'].filters.Alpha.enabled = 0");

     }
     else
     for(i in Slots2)
     {
    // NumOfBody = 2;

    // if(TestItem(eval("Items[Slots"+b+"[i].id].id")) != "")
    //        eval("d.images['"+i+""+b+"'].filters.Alpha.enabled = 1");
    // else   eval("d.images['"+i+""+b+"'].filters.Alpha.enabled = 0");

     }

}
var ups1;
var ups2;
function PrintTotalParams()
{
 
  sum_s=0;
  sum_om=0;
  sum_b=0;
  sum_d=0;
  dam_statr1 = 0;
  dam_statl1 = 0;
  dam_statr2 = 0;
  dam_statl2 = 0;
  var stats_1= 0;
  var stats_2= 0;
  Body1[3][1]=Body1[12][1]*5+10;
  Body1[4][1]=Body1[13][1]*5;
  Body1[2][1]=0;
  Body2[2][1]=0;
  for(i=7; i<=13; i++)
     {
     	  
     if(Body1[i][1] <= 0 && i <= 12 && i >= 7)
                tmp1=1;
     else tmp1= Body1[i][1];
                    
                     if(i == 12)
                     {
                     	if(Body1[0][1] == 'Дракон')
                     		 tmp1 += Body1[1][1]*2;
                     	else tmp1 += Body1[1][1];
                     }
                     if(i == 11)
                     {
                     	if(Body1[0][1] == 'Гном')
                     		 tmp1 += Body1[1][1];
                     }
                     if(i == 10)
                     {
                     	if(Body1[0][1] == 'Орк')
                     		 tmp1 += Body1[1][1];
                     }
                     if(i == 9)
                     {
                     	if(Body1[0][1] == 'Хоббит')
                     		 tmp1 += Body1[1][1];
                     }
                     if(i == 8)
                     {
                     	if(Body1[0][1] == 'Эльф')
                     		 tmp1 += Body1[1][1];
                     }
                     if(i == 7)
                     {
                     	if(Body1[0][1] == 'Человек')
                     		 tmp1 += Body1[1][1];
                     }
    
      sum_s+=1*tmp1;
     }
     tmp1 = 0;
  for(i=14; i<=29; i++)
     sum_om+=1*Body1[i][1];
  for(i=30; i<=33; i++)
  {
     sum_b+=1*Body1[i][1];
   
  }
  sum_b+=1*Body1[32][1];

  if(Slots1['ПРука'].damage!='')
  {
     var rd=Slots1['ПРука'].damage.split('-');
     sum_d+=1*rd[0]+1*rd[1];
     dam_statr1 = rd[1];
     
  }
  if(Slots1['ЛРука'].damage!='')
  {
     var ld=Slots1['ЛРука'].damage.split('-');
     sum_d+=1*ld[0]+1*ld[1];
     dam_statl1 = ld[1];
  }
  
  lvlr = 0.215*parseInt(Body1[1][1])+1.422*1;
  rate=((sum_s+sum_om*.2+sum_b*.1+sum_d*.25)*.1)*(lvlr);
 
  rate*=10;  
  t=rate;
  rate=Math.round(rate);
  if(t>rate) rate-=1;
  rate/=10;
  Body1[5][1]=rate;
  for(i=7; i<=13; i++)
  {
       if(i!=13)
       Body1[2][1]+=(1*Orig1[i][1])-(1*DefaultParams1[i][1]);
       else if (Body1[13][1] >10)  Body1[2][1]+=(1*Orig1[i][1])-10;
  }
	
  Body1[2][1] = Body1[2][1]*1;// - minusup*1;
	
  sum_s=0;
  sum_om=0;
  sum_b=0;
  sum_d=0;
  Body2[3][1]=Body2[12][1]*5+10;
  Body2[4][1]=Body2[13][1]*5;
  Body2[2][1]=0;
  tmp1 = 0;
for(i=7; i<=13; i++)
     {
     	  
     if(Body2[i][1] <= 0 && i <= 12 && i >= 7)
                tmp1=1;
     else tmp1= Body2[i][1];
                    
                     if(i == 12)
                     {
                     	if(Body2[0][1] == 'Дракон')
                     		 tmp1 += Body2[1][1]*2;
                     	else tmp1 += Body2[1][1];
                     }
                     if(i == 11)
                     {
                     	if(Body2[0][1] == 'Гном')
                     		 tmp1 += Body2[1][1];
                     }
                     if(i == 10)
                     {
                     	if(Body2[0][1] == 'Орк')
                     		 tmp1 += Body2[1][1];
                     }
                     if(i == 9)
                     {
                     	if(Body2[0][1] == 'Хоббит')
                     		 tmp1 += Body2[1][1];
                     }
                     if(i == 8)
                     {
                     	if(Body2[0][1] == 'Эльф')
                     		 tmp1 += Body2[1][1];
                     }
                     if(i == 7)
                     {
                     	if(Body2[0][1] == 'Человек')
                     		 tmp1 += Body2[1][1];
                     }
    
      sum_s+=1*tmp1;
     }
     tmp1= 0;
  for(i=14; i<=29; i++)
     sum_om+=1*Body2[i][1];
  for(i=30; i<=33; i++)
     sum_b+=1*Body2[i][1];
     
  sum_b+=1*Body2[32][1];

  if(Slots2['ПРука'].damage!='')
  {
     var rd=Slots2['ПРука'].damage.split('-');
     sum_d+=1*rd[0]+1*rd[1];
     dam_statr2 = rd[1];
     
  }
  if(Slots2['ЛРука'].damage!='')
  {
     var ld=Slots2['ЛРука'].damage.split('-');
     sum_d+=1*ld[0]+1*ld[1];
     dam_statl2 = ld[1];
  }

   lvlr = 0.215*parseInt(Body2[1][1])+1.422*1;
  rate=((sum_s+sum_om*.2+sum_b*.1+sum_d*.25)*.1)*(lvlr);
 
  rate*=10;
  t=rate;
  rate=Math.round(rate);
  if(t>rate) rate-=1;
  rate/=10;
  Body2[5][1]=rate;
  for(i=7; i<=13; i++)
  {
       if(i!=13)
       Body2[2][1]+=(1*Orig2[i][1])-(1*DefaultParams2[i][1]);
       else if (Body2[13][1] >10)  Body2[2][1]+=(1*Orig2[i][1])-10;
  }
  Body2[2][1] = Body2[2][1]*1;// - minusup2*1;
  
  Body1[6][1]*=100;
  Body1[6][1]=Math.round(Body1[6][1]);
  Body1[6][1]/=100;

  Body2[6][1]*=100;
  Body2[6][1]=Math.round(Body2[6][1]);
  Body2[6][1]/=100;

  str="<table cellpadding=0 cellspacing=0 border=0 align=center>";
        for(i=0; i<Body1.length-4; i++)
        {
             if((i>25 && i <= 29) || ((i>17 && i <= 21)))
             z=-1;
             else z=1;
             if(i==7)
             str+="<tr><td>&nbsp;</td><td >&nbsp;</td><td ALIGN=CENTER ><center><b>Статы</b></center></td><td>&nbsp;</td><td>&nbsp;</td></tr>";
             if(i==14)
             str+="<tr><td>&nbsp;</td><td ALIGN=CENTER>&nbsp;</td><td ALIGN=CENTER ><center><b>Мастерства и Антимастерства</b></center></td><td>&nbsp;</td><td>&nbsp;</td></tr>";
             if(i==22)
             str+="<tr><td>&nbsp;</td><td ALIGN=CENTER>&nbsp;</td><td ALIGN=CENTER><center><b>Обереги и Антиобереги</b></center></td><td>&nbsp;</td><td>&nbsp;</td></tr>";
             if(i==30)
             str+="<tr><td>&nbsp;</td><td ALIGN=CENTER>&nbsp;</td><td ALIGN=CENTER><center><b>Броня</b></center></td><td>&nbsp;</td><td>&nbsp;</td></tr>";
            
             if(i>=7 && i<=17 || i==1)
             {
                    
             		 if(Body1[i][1] <= 0 && i <= 12 && i >= 7)
                        tmp1=1;
                     else tmp1= Body1[i][1];
                     if(Body2[i][1] <= 0 && i <= 12 && i >= 7)
                        tmp2=1;
                     else tmp2= Body2[i][1];
                     
                     if(i == 7)
                     {
                     	str_stat1 = tmp1;
                     	str_stat2 = tmp2;
                     } 
                     
                     if(i == 12)
                     {
                     	if(Body1[0][1] == 'Дракон')
                     		 tmp1 += Body1[1][1]*2;
                     	else tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Дракон')
                     		 tmp2 += Body2[1][1]*2;
                     	else tmp2 += Body2[1][1];
                     }
                     if(i == 11)
                     {
                     	if(Body1[0][1] == 'Гном')
                     		 tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Гном')
                     		 tmp2 += Body2[1][1];
                     }
                     if(i == 10)
                     {
                     	if(Body1[0][1] == 'Орк')
                     		 tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Орк')
                     		 tmp2 += Body2[1][1];
                     }
                     if(i == 9)
                     {
                     	if(Body1[0][1] == 'Хоббит')
                     		 tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Хоббит')
                     		 tmp2 += Body2[1][1];
                     }
                     if(i == 8)
                     {
                     	if(Body1[0][1] == 'Эльф')
                     		 tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Эльф')
                     		 tmp2 += Body2[1][1];
                     }
                     if(i == 7)
                     {
                     	if(Body1[0][1] == 'Человек')
                     		 tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Человек')
                     		 tmp2 += Body2[1][1];
                     }
					 if(i <= 12 && i >= 7)
					 {
					 	stats_1 += tmp1*1;
					 	stats_2 += tmp2*1;
					 }
                     str+="<tr><td><input class=inputparam style='TEXT-ALIGN: right'  type=text size=3 value='"+Orig1[i][1]+"' onblur='reparams(1, "+i+", this.value)'></td><td ALIGN=CENTER ><nobr><center><span id='p1_"+i+"_id'>"+tmp1+"</span></nobr></center></td><td ALIGN=CENTER><center><nobr>"+Body1[i][0]+"</nobr></center></td><td ALIGN=CENTER><nobr><center><span id=p2"+i+"_id>"+tmp2+"</span></center></nobr></td><td><input class=inputparam style='TEXT-ALIGN: left' type=text size=3 value='"+Orig2[i][1]+"' onblur='reparams(2, "+i+", this.value)'></td></tr>";
             }
             else if(i ==  2) 
             {
             	ups1 = 0;
             	for(lvl = 1; lvl <= Body1[1][1]; lvl++)
             	{
             		ups1 += lvl*1;
             	}
             	ups1 += Body1[1][1]*3;
             	
             	ups2 = 0;
             	for(lvl = 1; lvl <= Body2[1][1]; lvl++)
             	{
             		ups2 += lvl*1;
             	}
             	ups2 += Body2[1][1]*3;
             	
             	str+="<tr><td></td><td ALIGN=CENTER><center>"+Body1[i][1]+"/"+ups1+"</center></td><td ALIGN=CENTER><center><nobr>Апы</nobr></center></td><td ALIGN=CENTER><center>"+Body2[i][1]+"/"+ups2+"</center></td></tr>";
             }
             else   
             { if(i==0) 
            	   str+="<tr><td></td><td ALIGN=CENTER><center>"+Body1[i][1]+"</center></td><td ALIGN=CENTER><center><nobr>"+Body1[i][0]+"</nobr></center></td><td ALIGN=CENTER><center>"+Body2[i][1]+"</center></td></tr>"; 
               else if(i==3)
               {
               	   		tmp1=0;
               	   		tmp2=0;
               			if(Body1[0][1] == 'Дракон')
                     		 tmp1 += Body1[1][1]*2;
                     	else tmp1 += Body1[1][1];
                     	if(Body2[0][1] == 'Дракон')
                     		 tmp2 += Body2[1][1]*2;
                     	else tmp2 += Body2[1][1];
                     	
                     	info_hp = ((Body1[i][1]*z)+(tmp1*5))*1;
                     	info_hp2 = ((Body2[i][1]*z)+(tmp2*5))*1;
                     	
               		str+="<tr><td>&nbsp;</td><td ALIGN=CENTER id='life1'><center>"+((Body1[i][1]*z)+(tmp1*5))*1+"</center></td><td ALIGN=CENTER><center><nobr>"+Body1[i][0]+"</nobr></center></td><td ALIGN=CENTER><center>"+((Body2[i][1]*z)+(tmp2*5))+"</center></td><td>&nbsp;</td></tr>";
               }
              else str+="<tr><td>&nbsp;</td><td ALIGN=CENTER ><center>"+Body1[i][1]*z+"</center></td><td ALIGN=CENTER><center><nobr>"+Body1[i][0]+"</nobr></center></td><td ALIGN=CENTER><center>"+Body2[i][1]*z+"</center></td><td>&nbsp;</td></tr>";
             }

        }
  str+="</table>";
  document.getElementById('params').innerHTML = str;
  TestSlots(1);  TestSlots(2);
  
  printPersInfo();
}
PrintTotalParams();

base = 36;
 
function EncodeChecksum(sum)
{
	var c, res = "";
	for (var i = 0; i < 4; i++){
		c = sum%16;
		sum -= c;
		sum /= 16;
		res += c.toString(16)
	}
	return (res);
}
 
function EncodeString(str)
{
	var i, n = 0, res = "", tmp;
	for (i = 0; i < str.length; i++){
		n += str.charCodeAt(i);
		tmp = str.charCodeAt(i).toString(base);
		if (tmp.length < 2) res += "0";
		res += tmp;
	}
	res += EncodeChecksum(n);
	return (res);
}
 
function DecodeOneChar(c)
{
	if (c <= "9" && c >= "0"){
		c = parseInt(c);
	} else if (c >= "a" &&  c <= "z"){
		c = c.charCodeAt(0) - 87;
	} else {
		c = 0;
	}
	return (c);
}
 
function DecodeString(str)
{
	var res = "", c, n = 0, sum1, sum2;
	for (i = 0; i < (str.length - 4) / 2; i++){
		c = base * DecodeOneChar(str.charAt(i*2)) + DecodeOneChar(str.charAt(i*2+1));
		n += c;
		c = String.fromCharCode(c);
		res += c;
	}
	sum1 = EncodeChecksum(n);
	sum2 = str.substr(str.length - 4, 4);
 
	if (sum1 != sum2){
		res = -1;
	}
	return (res);
}


function SaveBody(b)
{
      str="";
      op = new Array();
      sl = new Array();
      if(b == 1)
      {
         sl = Slots1;
         op=Orig1;
         
         
         if(Body1[0][1]== "Эльф")
            race="el";
      else if(Body1[0][1]== "Человек")
            race="hm";
      else if(Body1[0][1]== "Орк")
            race="or";
      else if(Body1[0][1]== "Гном")
            race="gn";
      else if(Body1[0][1]== "Хоббит")
            race="hb";
      else if(Body1[0][1]== "Дракон")
            race="dr";
            
            
      }
      else
      {
          sl = Slots2;
          op=Orig2;
          
          
          if(Body2[0][1]== "Эльф")
            race="el";
      else if(Body2[0][1]== "Человек")
            race="hm";
      else if(Body2[0][1]== "Орк")
            race="or";
      else if(Body2[0][1]== "Гном")
            race="gn";
      else if(Body2[0][1]== "Хоббит")
            race="hb";
      else if(Body2[0][1]== "Дракон")
            race="dr";
      }
    //  if(b == 1) ups = ups1; else ups = ups2;
      str+="Race,"+race+"|";
      str+="lvl,"+op[1][1]+"|";
     // str+="ups,"+ups+"|";
      for(i=7; i<18; i++)
      {
              str+=op[i][0]+",";
              str+=op[i][1]+"|";
      }
      var itemSave = '';
      for(i in sl)
      {
			if(sl[i].id != 'item_0')
    	    {
				for(var itemNum in Items[sl[i].id])
				{
					var itemValue = Items[sl[i].id][itemNum];
					
					if(Items[sl[i].id][itemNum] == undefined || Items[sl[i].id][itemNum] == 'undefined')
						itemValue = '';

					if(itemNum == 'ms6')	
						itemSave += itemValue + '|';
					else
		    	    	itemSave += itemValue + ',';
	    	    	
	    	    //	console.log(itemNum);
				}
    	    }
    	     
    	     sl[i].name = sl[i].name.replace(',', '__');
             for(j in sl[i])
             {
                   if(j != "ms6")// if(j != "twohand")
                    {
						// str+=j+":"+sl[i][j]+",";
						 str+=sl[i][j]+",";
                    }
                    else  str+=sl[i][j];
             }
             if(i != "ПСапоги")
                str+="|";
             
      } 

      str += "$" + itemSave;


      	$("#castersWindow2").dialog({
    		autoOpen: false,
    		width: 472,
    		buttons: {
    			"Закрыть": function() { 
    				$(this).dialog("close"); 
    			} 
    		}
    	});

     	$.post("http://localhost/file/save/", 
				{
			   		save: EncodeString(str)
				},
				function(response){
	   				var result = jQuery.parseJSON(response);
	   				//alert(result);
	   				$("#infoDiv2").html('Ваш код комплекта: '+result.hash+'<br/>Ссылка на комлект: <a target="_blank" href="http://localhost/file/save/Primer#'+result.hash+'">http://localhost/file/save/Primer#'+result.hash+'</a>');
	   			    $("#castersWindow2").dialog("open");
		});
      	
	    

	w = window.open("", "SavePrimer", "top=300,left=450,width=430,height=405,toolbar=0,location=0,directories=0,resizable=0,scrollbars=0,status=0,menubar=0");
	w.document.open();
	s = "<title>Сохранить комплект</title>";
	// s +='<LINK href="themes/stalkerz/styles.css" type=text/css rel=stylesheet>';
	s += "<textarea cols=51 rows=25 >"+EncodeString(str)+"</textarea>"; // выводит код сохранения (по старому)
	//    s += "<textarea cols=100 rows=40 >"+str+"</textarea>"; // под сохранением выводит пути сохранённого комплекта картинок
	w.document.write(s);
	w.document.close();
	w.focus();

}


function adapterLoad(b, set)
{
	 if (set != null && set != "")
     {
     	
     	    set = DecodeString(set.replace(' ', ''));
//console.log(set);
     	//    set = set.replace(' ', '');
     	    
     		 smimg = new Array();
              smimg['str'] = 'pitem100000692_wWh';
				 smimg['lov'] = 'pitem100000694_zGE'; 
				 smimg['reac'] = 'pitem100000698_gqj';
				 smimg['luck'] = 'pitem100000696_sx9';
				 smimg['angr'] = 'pitem100000702_0AI';
				 smimg['hp'] = 'pitem100000700_jTk';
				 smimg['kul'] = 'pitem100000712_PL7';
				 smimg['def'] = 'pitem100000710_RMW';
				 smimg['weap'] = 'pitem100000708_shv';
				 smimg['met'] = 'pitem100000706_Coy';
				 smimg['o_uvor'] = 'pitem100000716_G3b';
				 smimg['o_otv'] = 'pitem100000718_Pxe';
				 smimg['o_luck'] = 'pitem100000714_9LG';
				 smimg['o_angr'] = 'pitem100000720_TsZ';
				 smimg['m_o_uvor'] = 'pitem100000863_KaQ';
				 smimg['m_o_otv'] = 'pitem100000861_LSX';
				 smimg['m_o_luck'] = 'pitem100000857_2Ra';
				 smimg['m_o_angr'] = 'pitem100000859_YVC';
				 
 	  var saveSet = set.split('$');	

		 if(saveSet[1] != undefined)
		 {
			var  iSet = saveSet[1].split('|');
			for(var nSet in iSet)
			{ 
				var item = iSet[nSet].split(',');

				if(item[0] != undefined && item[0] != '')
				{
				//	item[0]  += '_999';
					
					var strItem = "Items['"+item[0]+"'] = new ItemParams("
					for(var jSet in item)
					{
						if(jSet != 0)
								strItem += ", \'"+ item[jSet]+ "\'";
						else  strItem +=  "\'"+item[jSet] +"\'";
					}
	
					strItem += ');';
					
					//console.log(strItem);
					eval(strItem);
				}
			}

			eval(MakeGroups());
			Group = new ItemGroups();
			
		 }
 	  	 
       AllSet = saveSet[0].split('|');
       race=AllSet[0].split(',');
       slvl=AllSet[1].split(',');
       
      // alert(lvl[1]);
      // ups=AllSet[2].split(',');
       ChangeRace(b, race[1]);
        op = new Array();
        sl = new Array();
        bp = new Array();
        if(b == 1)
        {
          sl = Slots1;
          op=Orig1;
          bp=Body1;
        }
       else
       {
           sl = Slots2;
           op=Orig2;
           bp=Body2;
       }
          op[1][1]=slvl[1];
          bp[1][1]=slvl[1];
          
         // op[2][1]=ups[1];
        //  bp[2][1]=ups[1];
          
          j=2;
          for(i=7; i<18; i++)
          {
               set=AllSet[j].split(',');
               op[i][1]=set[1];
               bp[i][1]=set[1];
               j++;
          }
          ind_i = 0;
          for(i in sl)
          {
             ind = 13+ind_i;
             set=AllSet[ind].split(',');
             ind_j=0;

             set[1] = set[1].replace('__', ',');
             
             for(j in sl[i])
             {
					if(set[ind_j] != undefined && set[ind_j] != 'undefined' && set[ind_j] && set[ind_j] != 0 && set[ind_j] != '0')
                	 sl[i][j]=set[ind_j];
					else sl[i][j]= '';
					
                  ind_j++;
                //  if(ind_j == 42 ) alert(set[ind_j]);
             }
             NumOfBody=b;
             NameOfSlot=i;
             NameOfImg=i+b;
             /* if(TestItem(eval("sl[NameOfSlot].id")) != "")
                 eval("d.images[NameOfImg].filters.Alpha.enabled = 1");
             else   eval("d.images[NameOfImg].filters.Alpha.enabled = 0");*/
             eval("d.images[NameOfImg].src = sl[i].img");
             
              sdiv = document.getElementById(NameOfSlot+""+NumOfBody);
			  	 sdiv.innerHTML = '';
		
				 if(smimg[set[42]])
				 {
				 	sdiv.innerHTML += '<img border="0" width="9" height="9" src="http://resources.apeha.ru/upload/'+smimg[set[42]]+'.gif">';
				 }

				 if(smimg[set[56]])
				 {
				 	sdiv.innerHTML += '<img border="0" width="9" height="9" src="http://resources.apeha.ru/upload/'+smimg[set[56]]+'.gif">';
				 }

			   if(set[59] != undefined && set[59] != 'undefined' && set[59])
			   {
			   	   sdiv.innerHTML += '<img title="Усиление" border="0" height="9" src="http://resources.apeha.ru/upload/1_5438.gif">';
			   }
 			   
             MinusParams();
             PlusParams();
             PlusParams();
             ind_i++;
          }

     }

	  reparams(b, 1, slvl[1]);
      PrintTotalParams();
}

function Loadsave(b, promt)
{
		var  set = '';
	
		if(!promt)
		{
    		set = prompt("Введите сюда код сохраненного комплекта", "");

    		if(set != undefined && set != 'undefined' && set != '')
    		{
    			$.post("./files/save/", {id: set},
    					   function(response){
    					   		var result = jQuery.parseJSON(response);
    					   		
    					   		if(result.success && result.data)
    					   		{
    					   			set = result.data;
    					   			adapterLoad(b, set);
    					   			return ;
    					   		}
    					   		else alert('Не удалось загрузить комплект');
    					   }
    			);
    		}

		}
		else
		{  
			set = promt;
			adapterLoad(b, set);
		}
}

function openSave()
{
	var save = getUrlSave();

	if(save != undefined && save != 'undefined' && save != '')
	{
		$.post("./files/save/", {id: save},
				   function(response){
				   		var result = jQuery.parseJSON(response);
				   		
				   		if(result.success && result.data)
				   		{
				   			Loadsave(2, result.data);
				   		}
				   		else alert('Не удалось загрузить комплект');
				   }
		);
	}
}

openSave();